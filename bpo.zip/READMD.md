1.安安 ~ 如果 https://a1043332.github.io/bpo 失效了，請在 index.html 按右鍵>開啟檔案>選擇瀏覽器，即可使用哦！
2.點選圖片可以回到首頁
3.在 Origin Model 中 Service rate of Buying TypeI(m) 為 60 / 80= 0.75、Service rate of Buying TypeII(m) 為 60 / 130 = 0.46
4.在 New Model 中 Service rate of Order(m) 為 60 / 40 = 1.5 、Service rate of Making TypeI(m) 為 60 / 40 = 1.5 、Service rate of Making TypeII(m) 為 60 / 90 = 0.667 ， 我們假設有 40% 的人會線上訂購